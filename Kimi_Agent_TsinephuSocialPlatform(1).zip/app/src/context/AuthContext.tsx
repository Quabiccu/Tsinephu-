import { createContext, useContext, useState, useEffect } from 'react';
import type { User, AuthState } from '@/types';

interface AuthContextType extends AuthState {
  login: (username: string, displayName: string, avatar?: string) => User;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  updateAvatar: (avatarUrl: string) => void;
  startObserverMode: () => void;
  exitObserverMode: () => void;
  isObserver: boolean;
  isAdmin: boolean;
  banUser: (userId: string, reason: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function generateAvatar(username: string): string {
  const encoded = encodeURIComponent(username);
  return `https://api.dicebear.com/7.x/avataaars/svg?seed=${encoded}&backgroundColor=b6e3f4`;
}

// Global users storage key
const GLOBAL_USERS_KEY = 'tsinephu-users';
const BANNED_USERS_KEY = 'tsinephu-banned-users';

// Admin usernames - @anatolcyman_ is the main admin
const ADMIN_USERNAMES = ['anatolcyman_', 'admin', 'tsinephu_official'];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>(() => {
    const saved = localStorage.getItem('tsinephu-auth');
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...parsed,
        user: parsed.user ? {
          ...parsed.user,
          joinedAt: new Date(parsed.user.joinedAt),
        } : null,
        isObserver: parsed.isObserver || false,
      };
    }
    return { user: null, isAuthenticated: false, isObserver: false };
  });

  useEffect(() => {
    localStorage.setItem('tsinephu-auth', JSON.stringify({
      ...authState,
      user: authState.user ? {
        ...authState.user,
        joinedAt: authState.user.joinedAt.toISOString(),
      } : null,
    }));
  }, [authState]);

  const isObserver = authState.isObserver || false;
  
  // Check if current user is admin
  const isAdmin = authState.user ? ADMIN_USERNAMES.includes(authState.user.username) : false;

  const registerUserGlobally = (user: User) => {
    const saved = localStorage.getItem(GLOBAL_USERS_KEY);
    const users: User[] = saved ? JSON.parse(saved) : [];
    
    // Check if user already exists
    const existingIndex = users.findIndex(u => u.id === user.id || u.username === user.username);
    
    if (existingIndex >= 0) {
      // Update existing user
      users[existingIndex] = { ...users[existingIndex], ...user };
    } else {
      // Add new user
      users.push(user);
    }
    
    localStorage.setItem(GLOBAL_USERS_KEY, JSON.stringify(users));
  };

  const login = (username: string, displayName: string, avatar?: string): User => {
    const newUser: User = {
      id: `user_${Date.now()}`,
      username: username.toLowerCase().replace(/\s+/g, '_'),
      displayName: displayName || username,
      avatar: avatar || generateAvatar(username),
      bio: '',
      joinedAt: new Date(),
      following: [],
      followers: [],
    };

    // Register in global users list
    registerUserGlobally(newUser);

    setAuthState({
      user: newUser,
      isAuthenticated: true,
    });

    return newUser;
  };

  const logout = () => {
    setAuthState({
      user: null,
      isAuthenticated: false,
    });
    localStorage.removeItem('tsinephu-auth');
  };

  const updateUser = (updates: Partial<User>) => {
    if (authState.user) {
      setAuthState({
        ...authState,
        user: { ...authState.user, ...updates },
      });
    }
  };

  const updateAvatar = (avatarUrl: string) => {
    if (authState.user) {
      setAuthState({
        ...authState,
        user: { ...authState.user, avatar: avatarUrl },
      });
    }
  };

  const startObserverMode = () => {
    setAuthState({
      user: null,
      isAuthenticated: false,
      isObserver: true,
    });
  };

  const exitObserverMode = () => {
    setAuthState({
      user: null,
      isAuthenticated: false,
      isObserver: false,
    });
  };

  const banUser = (userId: string, reason: string) => {
    if (!isAdmin) return;
    
    const saved = localStorage.getItem(BANNED_USERS_KEY);
    const bannedUsers: { userId: string; reason: string; bannedAt: string; bannedBy: string }[] = saved ? JSON.parse(saved) : [];
    
    bannedUsers.push({
      userId,
      reason,
      bannedAt: new Date().toISOString(),
      bannedBy: authState.user?.username || 'unknown',
    });
    
    localStorage.setItem(BANNED_USERS_KEY, JSON.stringify(bannedUsers));
    
    // Also update the user's banned status in global users
    const usersSaved = localStorage.getItem(GLOBAL_USERS_KEY);
    if (usersSaved) {
      const users: User[] = JSON.parse(usersSaved);
      const updatedUsers = users.map(u => 
        u.id === userId ? { ...u, isBanned: true, banReason: reason } : u
      );
      localStorage.setItem(GLOBAL_USERS_KEY, JSON.stringify(updatedUsers));
    }
  };

  return (
    <AuthContext.Provider value={{ 
      ...authState, 
      login, 
      logout, 
      updateUser, 
      updateAvatar,
      startObserverMode,
      exitObserverMode,
      isObserver,
      isAdmin,
      banUser,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
