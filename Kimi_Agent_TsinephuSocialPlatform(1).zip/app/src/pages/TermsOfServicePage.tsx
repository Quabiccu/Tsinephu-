import { useState } from 'react';
import { Scroll, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/context/LanguageContext';
import { Checkbox } from '@/components/ui/checkbox';

interface TermsOfServicePageProps {
  onAccept?: () => void;
  onClose?: () => void;
  showAcceptButton?: boolean;
}

export function TermsOfServicePage({ onAccept, onClose, showAcceptButton = false }: TermsOfServicePageProps) {
  const { t } = useLanguage();
  const [accepted, setAccepted] = useState(false);

  const paragraphs = t('termsOfService').split(/\d+\.\s/).filter(Boolean);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-full bg-[#DC143C]/10 flex items-center justify-center">
            <Scroll className="h-6 w-6 text-[#DC143C]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{t('termsShort') || 'Terms of Service'}</h1>
            <p className="text-sm text-muted-foreground">Tsinephu — Quabiccu | 2026</p>
          </div>
          {onClose && (
            <Button variant="ghost" size="sm" className="ml-auto" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Content */}
        <div className="prose prose-sm max-w-none dark:prose-invert">
          <div className="bg-muted/50 rounded-xl p-6 space-y-6">
            {paragraphs.map((paragraph, index) => {
              const lines = paragraph.trim().split('\n').filter(Boolean);
              const title = lines[0]?.replace(':', '').trim();
              const content = lines.slice(1).join(' ').trim();
              
              return (
                <div key={index} className="space-y-2">
                  <h3 className="font-semibold text-lg text-foreground">
                    {index + 1}. {title || paragraph.substring(0, 50)}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {content || paragraph}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Full text fallback */}
          {paragraphs.length === 0 && (
            <div className="bg-muted/50 rounded-xl p-6">
              <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                {t('termsOfService')}
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="mt-8 p-4 bg-[#DC143C]/5 rounded-xl border border-[#DC143C]/20">
          <p className="text-sm text-[#DC143C] font-medium">
            {t('tosRequired') || 'By using Tsinephu, you acknowledge and agree to these terms.'}
          </p>
        </div>

        {/* Accept button */}
        {showAcceptButton && (
          <div className="mt-8 space-y-4">
            <div className="flex items-start gap-3">
              <Checkbox
                id="accept-tos"
                checked={accepted}
                onCheckedChange={(checked) => setAccepted(checked === true)}
                className="mt-1"
              />
              <label htmlFor="accept-tos" className="text-sm leading-relaxed cursor-pointer">
                {t('acceptTerms') || 'I have read and accept the Terms of Service. I understand that I am solely responsible for all content I post on Tsinephu.'}
              </label>
            </div>
            <Button
              className="w-full bg-[#DC143C] hover:bg-[#B01030]"
              disabled={!accepted}
              onClick={onAccept}
            >
              <Check className="h-4 w-4 mr-2" />
              {t('continue') || 'Continue'}
            </Button>
            {!accepted && (
              <p className="text-xs text-muted-foreground text-center">
                {t('mustAcceptTerms') || 'You must accept the Terms of Service to use Tsinephu.'}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
