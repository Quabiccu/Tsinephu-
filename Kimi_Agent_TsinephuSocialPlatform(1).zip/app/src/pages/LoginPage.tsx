import { useState, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Chrome, User, ChevronDown, Camera, X } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export function LoginPage() {
  const { login, startObserverMode } = useAuth();
  const { t, language, setLanguage, livingLanguages, ancientLanguages } = useLanguage();
  const [step, setStep] = useState<'welcome' | 'username'>('welcome');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [languageSearch, setLanguageSearch] = useState('');

  const allLanguages = [...livingLanguages, ...ancientLanguages];
  const currentLang = allLanguages.find(l => l.code === language);

  const filteredLiving = languageSearch.trim() 
    ? livingLanguages.filter(lang => 
        lang.name.toLowerCase().includes(languageSearch.toLowerCase().trim())
      )
    : livingLanguages;
  
  const filteredAncient = languageSearch.trim() 
    ? ancientLanguages.filter(lang => 
        lang.name.toLowerCase().includes(languageSearch.toLowerCase().trim())
      )
    : ancientLanguages;

  const handleObserverMode = () => {
    startObserverMode();
  };

  const handleGoogleLogin = () => {
    setIsLoading(true);
    // Simulate Google OAuth flow
    setTimeout(() => {
      setIsLoading(false);
      // Simulate getting user data from Google
      const mockGooglePicture = `https://api.dicebear.com/7.x/avataaars/svg?seed=${Date.now()}&backgroundColor=b6e3f4`;
      setProfilePhoto(mockGooglePicture);
      setStep('username');
    }, 1500);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    setProfilePhoto(null);
  };

  const handleCompleteSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      login(username, displayName || username, profilePhoto || undefined);
    }
  };

  if (step === 'welcome') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="w-full max-w-md">
          {/* Language Selector */}
          <div className="flex justify-end mb-6">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 px-3 py-2 rounded-full border border-border hover:bg-muted transition-colors text-sm">
                  <span>{currentLang?.flag}</span>
                  <span className="max-w-[150px] truncate">{currentLang?.name}</span>
                  <ChevronDown className="h-4 w-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-72 max-h-[500px] overflow-y-auto">
                <div className="p-2 sticky top-0 bg-popover z-10 border-b">
                  <Input
                    placeholder={t('search') + '...'}
                    value={languageSearch}
                    onChange={(e) => setLanguageSearch(e.target.value)}
                    className="h-8 text-sm"
                    onClick={(e) => e.stopPropagation()}
                  />
                </div>
                
                {/* Living Languages */}
                {!languageSearch.trim() && (
                  <div className="px-2 py-1 text-xs font-semibold text-muted-foreground">
                    {t('livingLanguages')} ({filteredLiving.length})
                  </div>
                )}
                <div className="py-1">
                  {filteredLiving.map((lang) => (
                    <DropdownMenuItem
                      key={lang.code}
                      onClick={() => setLanguage(lang.code)}
                      className={language === lang.code ? 'bg-primary/10' : ''}
                    >
                      <span className="mr-2">{lang.flag}</span>
                      {lang.name}
                    </DropdownMenuItem>
                  ))}
                </div>

                {/* Ancient Languages */}
                {filteredAncient.length > 0 && (
                  <>
                    <div className="border-t my-1" />
                    <div className="px-2 py-1 text-xs font-semibold text-muted-foreground">
                      🏛️ {t('ancientSymbolicLanguages')} ({filteredAncient.length})
                    </div>
                    <div className="py-1">
                      {filteredAncient.map((lang) => (
                        <DropdownMenuItem
                          key={lang.code}
                          onClick={() => setLanguage(lang.code)}
                          className={language === lang.code ? 'bg-primary/10' : ''}
                        >
                          <span className="mr-2">{lang.flag}</span>
                          {lang.name}
                        </DropdownMenuItem>
                      ))}
                    </div>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="text-center mb-10">
            <div className="flex justify-center mb-6">
              <img 
                src="/logo.png" 
                alt="Tsinephu" 
                className="h-28 w-auto"
              />
            </div>
            <h1 className="text-4xl font-bold mb-3">{t('welcome')}</h1>
            <p className="text-muted-foreground text-lg">
              {t('welcomeSubtitle')}
            </p>
          </div>

          <div className="space-y-4">
            <Button
              variant="outline"
              size="lg"
              className="w-full h-14 text-lg gap-3 rounded-full border-2"
              onClick={handleGoogleLogin}
              disabled={isLoading}
            >
              <Chrome className="h-5 w-5" />
              {isLoading ? t('connecting') : t('continueWithGoogle')}
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">
                  {t('or')}
                </span>
              </div>
            </div>

            <Button
              variant="secondary"
              size="lg"
              className="w-full h-14 text-lg gap-3 rounded-full"
              onClick={() => setStep('username')}
            >
              <User className="h-5 w-5" />
              {t('createAccount')}
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">
                  {t('or')}
                </span>
              </div>
            </div>

            <Button
              variant="ghost"
              size="lg"
              className="w-full h-14 text-lg gap-3 rounded-full border border-dashed border-muted-foreground/30 hover:border-primary hover:bg-primary/5"
              onClick={handleObserverMode}
            >
              <span className="text-xl">👁️</span>
              {t('continueAsObserver')}
            </Button>
          </div>

          <p className="text-center text-sm text-muted-foreground mt-8">
            {t('termsText')}
          </p>

          {/* Footer */}
          <div className="text-center mt-12 space-y-2">
            <p className="text-xs text-muted-foreground">
              2026, all rights reserved for Quabiccu
            </p>
            <p className="text-xs text-muted-foreground">
              For questions: quabiccuteamoff@gmail.com
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-[#DC143C] flex items-center justify-center">
              <span className="text-yellow-400 text-3xl">⚡</span>
            </div>
          </div>
          <h1 className="text-2xl font-bold mb-2">{t('chooseUsername')}</h1>
          <p className="text-muted-foreground">
            {t('usernameSubtitle')}
          </p>
        </div>

        <form onSubmit={handleCompleteSignup} className="space-y-4">
          {/* Profile Photo Upload */}
          <div className="flex flex-col items-center space-y-3 mb-6">
            <div className="relative">
              <div 
                className="w-24 h-24 rounded-full bg-muted flex items-center justify-center overflow-hidden border-2 border-dashed border-muted-foreground/30 cursor-pointer hover:border-primary transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                {profilePhoto ? (
                  <img src={profilePhoto} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <Camera className="h-8 w-8 text-muted-foreground" />
                )}
              </div>
              {profilePhoto && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRemovePhoto();
                  }}
                  className="absolute -top-1 -right-1 w-6 h-6 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center hover:bg-destructive/90"
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="text-sm text-primary hover:underline"
            >
              {profilePhoto ? t('changePhoto') : t('uploadPhoto')}
            </button>
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">{t('username')}</Label>
            <Input
              id="username"
              placeholder="@username"
              value={username}
              onChange={(e) => setUsername(e.target.value.replace(/\s+/g, '_').toLowerCase())}
              className="h-12 rounded-xl"
              autoFocus
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="displayName">{t('displayName')}</Label>
            <Input
              id="displayName"
              placeholder={t('displayNamePlaceholder')}
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="h-12 rounded-xl"
            />
          </div>

          <div className="flex items-start gap-3 p-3 bg-muted/50 rounded-xl">
            <Checkbox
              id="terms-checkbox"
              checked={acceptedTerms}
              onCheckedChange={(checked) => setAcceptedTerms(checked === true)}
              className="mt-0.5"
            />
            <label htmlFor="terms-checkbox" className="text-sm leading-relaxed cursor-pointer">
              {t('acceptTerms') || 'I have read and accept the'} <button type="button" onClick={() => window.open('/terms', '_blank')} className="text-primary underline hover:text-primary/80">{t('termsShort') || 'Terms of Service'}</button>. {t('userAssumesResponsibility') || 'I understand that I am solely responsible for all content I post.'}
            </label>
          </div>

          <Button
            type="submit"
            size="lg"
            className="w-full h-12 text-lg mt-2 rounded-full bg-[#DC143C] hover:bg-[#B01030] text-white"
            disabled={!username.trim() || !acceptedTerms}
          >
            <span className="text-yellow-400 mr-2">⚡</span>
            {t('getStarted')}
          </Button>

          <Button
            type="button"
            variant="ghost"
            className="w-full"
            onClick={() => {
              setStep('welcome');
              setProfilePhoto(null);
            }}
          >
            {t('back')}
          </Button>
        </form>
      </div>
    </div>
  );
}
