import { useState, useCallback, useEffect } from 'react';
import { MapContainer, TileLayer, Polygon, useMapEvents, Marker, Popup, Circle, Rectangle, useMap, Polyline } from 'react-leaflet';
import { useLanguage } from '@/context/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { 
  X, Map as MapIcon, Undo, Redo, Trash2, Edit2, Palette, Check, 
  Search, Download, Upload, Plus, Minus, Crosshair,
  Square, Circle as CircleIcon, Hexagon, Type, Ruler,
  Layers, FileJson, Copy, Eye, EyeOff, Lock, Unlock,
  Maximize2, Minimize2, Navigation,
  Magnet
} from 'lucide-react';
import type { MapData, MapZone, MapMarker } from '@/types';
import 'leaflet/dist/leaflet.css';
import { Icon, latLng } from 'leaflet';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface MapParnikDrawerProps {
  onSave: (mapData: MapData) => void;
  onCancel: () => void;
  initialData?: MapData;
}

type DrawingTool = 'polygon' | 'circle' | 'rectangle' | 'marker' | 'text' | 'line' | 'distance';
type MapStyle = 'standard' | 'satellite' | 'terrain' | 'dark';

// Layer interface for advanced layer management
interface Layer {
  id: string;
  name: string;
  zones: MapZone[];
  markers: MapMarker[];
  visible: boolean;
  locked: boolean;
  color: string;
}

// History entry for undo/redo
interface HistoryEntry {
  layers: Layer[];
  activeLayerId: string;
}

// Custom marker icons
const editIcon = new Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjREMxNDNDIiBzdHJva2Utd2lkdGg9IjMiPjxjaXJjbGUgY3g9IjEyIiBjeT0iMTIiIHI9IjgiLz48L3N2Zz4=',
  iconSize: [16, 16],
  iconAnchor: [8, 8],
});

const markerIcon = new Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI0RDMTQzQyI+PHBhdGggZD0iTTEyIDJDOC4xMyAyIDUgNS4xMyA1IDljMCA1LjI1IDcgMTMgNyAxM3M3LTcuNzUgNy0xM2MwLTMuODctMy4xMy03LTctN3ptMCA5LjVjLTEuMzggMC0yLjUtMS4xMi0yLjUtMi41czEuMTItMi41IDIuNS0yLjUgMi41IDEuMTIgMi41IDIuNS0xLjEyIDIuNS0yLjUgMi41eiIvPjwvc3ZnPg==',
  iconSize: [28, 36],
  iconAnchor: [14, 36],
});

const distanceIcon = new Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzAwMDAwMCI+PGNpcmNsZSBjeD0iMTIiIGN5PSIxMiIgcj0iNCIvPjwvc3ZnPg==',
  iconSize: [10, 10],
  iconAnchor: [5, 5],
});

// Map style URLs
const mapStyles: Record<MapStyle, { url: string; name: string }> = {
  standard: { url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', name: 'Standard' },
  satellite: { url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', name: 'Satellite' },
  terrain: { url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', name: 'Terrain' },
  dark: { url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', name: 'Dark' },
};

// Drawing handler component
function DrawingHandler({
  tool,
  isDrawing,
  currentPath,
  setCurrentPath,
  onFinishDrawing,
  onAddMarker,
  circleCenter,
  setCircleCenter,
  setCircleRadius,
  rectangleStart,
  setRectangleStart,
  onAddDistancePoint,
  snapToGrid,
  gridSize,
}: {
  tool: DrawingTool;
  isDrawing: boolean;
  currentPath: [number, number][];
  setCurrentPath: (path: [number, number][]) => void;
  onFinishDrawing: () => void;
  onAddMarker: (lat: number, lng: number) => void;
  circleCenter: [number, number] | null;
  setCircleCenter: (center: [number, number] | null) => void;
  setCircleRadius: (radius: number) => void;
  rectangleStart: [number, number] | null;
  setRectangleStart: (start: [number, number] | null) => void;
  onAddDistancePoint?: (lat: number, lng: number) => void;
  snapToGrid: boolean;
  gridSize: number;
}) {
  const snap = (value: number) => {
    if (!snapToGrid) return value;
    return Math.round(value / gridSize) * gridSize;
  };

  useMapEvents({
    click(e) {
      let { lat, lng } = e.latlng;
      lat = snap(lat);
      lng = snap(lng);
      
      if (!isDrawing) return;

      if (tool === 'polygon') {
        setCurrentPath([...currentPath, [lat, lng]]);
      } else if (tool === 'line' || tool === 'distance') {
        setCurrentPath([...currentPath, [lat, lng]]);
        onAddDistancePoint?.(lat, lng);
      } else if (tool === 'circle') {
        if (!circleCenter) {
          setCircleCenter([lat, lng]);
        } else {
          const radius = latLng(circleCenter[0], circleCenter[1]).distanceTo(latLng(lat, lng));
          setCircleRadius(radius);
          onFinishDrawing();
        }
      } else if (tool === 'rectangle') {
        if (!rectangleStart) {
          setRectangleStart([lat, lng]);
        } else {
          onFinishDrawing();
        }
      } else if (tool === 'marker') {
        onAddMarker(lat, lng);
      }
    },
    mousemove(e) {
      if (tool === 'circle' && circleCenter && isDrawing) {
        const radius = latLng(circleCenter[0], circleCenter[1]).distanceTo(e.latlng);
        setCircleRadius(radius);
      }
    },
    dblclick() {
      if ((tool === 'polygon' || tool === 'line' || tool === 'distance') && isDrawing && currentPath.length >= 2) {
        onFinishDrawing();
      }
    },
  });
  return null;
}

// Map controller for programmatic control
function MapController({ 
  center, 
  zoom
}: { 
  center: [number, number]; 
  zoom: number;
}) {
  const map = useMap();
  
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);

  return null;
}

// Calculate polygon area (approximate)
function calculatePolygonArea(coords: [number, number][]): number {
  if (coords.length < 3) return 0;
  let area = 0;
  for (let i = 0; i < coords.length; i++) {
    const j = (i + 1) % coords.length;
    area += coords[i][1] * coords[j][0];
    area -= coords[j][1] * coords[i][0];
  }
  return Math.abs(area) * 111.32 * 111.32 / 2; // Rough conversion to km²
}

// Calculate distance between two points in km
function calculateDistance(p1: [number, number], p2: [number, number]): number {
  return latLng(p1[0], p1[1]).distanceTo(latLng(p2[0], p2[1])) / 1000;
}

// Calculate total distance of a path
function calculateTotalDistance(path: [number, number][]): number {
  if (path.length < 2) return 0;
  let total = 0;
  for (let i = 0; i < path.length - 1; i++) {
    total += calculateDistance(path[i], path[i + 1]);
  }
  return total;
}

// Helper component for map click handling in edit mode
function MapClickHandler({ onClick }: { onClick: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(e) {
      const { lat, lng } = e.latlng;
      onClick(lat, lng);
    },
  });
  return null;
}

// Get default fill opacity
const DEFAULT_FILL_OPACITY = 0.3;
const DEFAULT_STROKE_WIDTH = 2;

export function MapParnikDrawer({ onSave, onCancel, initialData }: MapParnikDrawerProps) {
  const { t } = useLanguage();
  
  // Layer management
  const [layers, setLayers] = useState<Layer[]>(() => {
    if (initialData) {
      return [{
        id: 'layer_1',
        name: 'Layer 1',
        zones: initialData.zones || [],
        markers: initialData.markers || [],
        visible: true,
        locked: false,
        color: '#DC143C',
      }];
    }
    return [{
      id: 'layer_1',
      name: 'Layer 1',
      zones: [],
      markers: [],
      visible: true,
      locked: false,
      color: '#DC143C',
    }];
  });
  
  const [activeLayerId, setActiveLayerId] = useState<string>('layer_1');
  
  // Get active layer
  const activeLayer = layers.find(l => l.id === activeLayerId) || layers[0];
  
  // Derived state from active layer
  const zones = activeLayer?.zones || [];
  const markers = activeLayer?.markers || [];
  
  const [currentPath, setCurrentPath] = useState<[number, number][]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<DrawingTool>('polygon');
  const [zoneName, setZoneName] = useState('');
  const [selectedColor, setSelectedColor] = useState('#DC143C');
  const [mapCenter, setMapCenter] = useState<[number, number]>(
    initialData ? [initialData.center.lat, initialData.center.lng] : [20, 0]
  );
  const [mapZoom, setMapZoom] = useState(initialData?.zoom || 2);
  const [mapStyle, setMapStyle] = useState<MapStyle>('standard');
  
  // Circle drawing state
  const [circleCenter, setCircleCenter] = useState<[number, number] | null>(null);
  const [circleRadius, setCircleRadius] = useState(0);
  
  // Rectangle drawing state
  const [rectangleStart, setRectangleStart] = useState<[number, number] | null>(null);
  
  // Edit mode states
  const [editingZoneId, setEditingZoneId] = useState<string | null>(null);
  const [showZoneEditor, setShowZoneEditor] = useState(false);
  const [selectedPointIndex, setSelectedPointIndex] = useState<number | null>(null);
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  
  // View options
  const [showLabels, setShowLabels] = useState(true);
  const [showMeasurements, setShowMeasurements] = useState(false);
  
  // Import/Export dialogs
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importData, setImportData] = useState('');
  
  // Layer management dialog
  const [showLayerDialog, setShowLayerDialog] = useState(false);
  const [newLayerName, setNewLayerName] = useState('');
  
  // Distance measurement
  const [distancePoints, setDistancePoints] = useState<[number, number][]>([]);
  const [measuredDistance, setMeasuredDistance] = useState<number>(0);
  
  // Fullscreen mode
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  // GeoJSON dialog
  const [showGeoJSONDialog, setShowGeoJSONDialog] = useState(false);
  const [geoJSONData, setGeoJSONData] = useState('');

  // Snap-to-grid
  const [snapToGrid, setSnapToGrid] = useState(false);
  const [gridSize, setGridSize] = useState(0.01); // ~1km at equator

  // Opacity and stroke width
  const [fillOpacity, setFillOpacity] = useState(DEFAULT_FILL_OPACITY);
  const [strokeWidth, setStrokeWidth] = useState(DEFAULT_STROKE_WIDTH);

  // History for undo/redo
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const maxHistorySize = 50;

  const colors = [
    { color: '#DC143C', name: 'Red' },
    { color: '#FFD700', name: 'Yellow' },
    { color: '#4169E1', name: 'Blue' },
    { color: '#32CD32', name: 'Green' },
    { color: '#FF8C00', name: 'Orange' },
    { color: '#9370DB', name: 'Purple' },
    { color: '#00CED1', name: 'Cyan' },
    { color: '#FF1493', name: 'Pink' },
    { color: '#8B4513', name: 'Brown' },
    { color: '#2F4F4F', name: 'Slate' },
  ];


  // Undo
  const undo = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      const entry = history[newIndex];
      setLayers(JSON.parse(JSON.stringify(entry.layers)));
      setActiveLayerId(entry.activeLayerId);
      setHistoryIndex(newIndex);
    }
  }, [history, historyIndex]);

  // Redo
  const redo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      const entry = history[newIndex];
      setLayers(JSON.parse(JSON.stringify(entry.layers)));
      setActiveLayerId(entry.activeLayerId);
      setHistoryIndex(newIndex);
    }
  }, [history, historyIndex]);

  // Push current state to history
  const pushHistory = useCallback(() => {
    setHistory(prev => {
      const newHistory = prev.slice(0, historyIndex + 1);
      newHistory.push({ 
        layers: JSON.parse(JSON.stringify(layers)), 
        activeLayerId 
      });
      if (newHistory.length > maxHistorySize) newHistory.shift();
      return newHistory;
    });
    setHistoryIndex(prev => {
      const newIndex = Math.min(prev + 1, maxHistorySize - 1);
      return newIndex;
    });
  }, [layers, activeLayerId, historyIndex]);

  // Update active layer
  const updateActiveLayer = (updates: Partial<Layer>) => {
    pushHistory();
    setLayers(prev => prev.map(l => 
      l.id === activeLayerId ? { ...l, ...updates } : l
    ));
  };

  const startDrawing = (selectedTool: DrawingTool) => {
    setTool(selectedTool);
    setIsDrawing(true);
    setCurrentPath([]);
    setCircleCenter(null);
    setCircleRadius(0);
    setRectangleStart(null);
    setEditingZoneId(null);
    setShowZoneEditor(false);
    setDistancePoints([]);
    setMeasuredDistance(0);
    setSelectedPointIndex(null);
  };

  const finishDrawing = useCallback(() => {
    pushHistory();
    if (tool === 'polygon' && currentPath.length >= 3) {
      const newZone: MapZone = {
        id: `zone_${Date.now()}`,
        name: zoneName.trim() || `Zone ${zones.length + 1}`,
        paths: currentPath.map(([lat, lng]) => ({ lat, lng })),
        color: selectedColor,
        type: 'polygon',
        fillOpacity,
        strokeWidth,
      };
      updateActiveLayer({ zones: [...zones, newZone] });
      setCurrentPath([]);
      setZoneName('');
    } else if (tool === 'line' && currentPath.length >= 2) {
      const newZone: MapZone = {
        id: `zone_${Date.now()}`,
        name: zoneName.trim() || `Line ${zones.length + 1}`,
        paths: currentPath.map(([lat, lng]) => ({ lat, lng })),
        color: selectedColor,
        type: 'polygon',
        fillOpacity,
        strokeWidth,
      };
      updateActiveLayer({ zones: [...zones, newZone] });
      setCurrentPath([]);
      setZoneName('');
    } else if (tool === 'distance' && currentPath.length >= 2) {
      const distance = calculateTotalDistance(currentPath);
      setMeasuredDistance(distance);
    } else if (tool === 'circle' && circleCenter && circleRadius > 0) {
      const newZone: MapZone = {
        id: `zone_${Date.now()}`,
        name: zoneName.trim() || `Circle ${zones.length + 1}`,
        paths: [{ lat: circleCenter[0], lng: circleCenter[1] }],
        color: selectedColor,
        type: 'circle',
        radius: circleRadius,
        fillOpacity,
        strokeWidth,
      };
      updateActiveLayer({ zones: [...zones, newZone] });
      setCircleCenter(null);
      setCircleRadius(0);
      setZoneName('');
    } else if (tool === 'rectangle' && rectangleStart && currentPath.length >= 2) {
      const endPoint = currentPath[currentPath.length - 1];
      const newZone: MapZone = {
        id: `zone_${Date.now()}`,
        name: zoneName.trim() || `Rectangle ${zones.length + 1}`,
        paths: [
          { lat: rectangleStart[0], lng: rectangleStart[1] },
          { lat: endPoint[0], lng: rectangleStart[1] },
          { lat: endPoint[0], lng: endPoint[1] },
          { lat: rectangleStart[0], lng: endPoint[1] },
        ],
        color: selectedColor,
        type: 'rectangle',
        fillOpacity,
        strokeWidth,
      };
      updateActiveLayer({ zones: [...zones, newZone] });
      setRectangleStart(null);
      setCurrentPath([]);
      setZoneName('');
    }
    setIsDrawing(false);
  }, [tool, currentPath, circleCenter, circleRadius, rectangleStart, zoneName, zones.length, selectedColor, fillOpacity, strokeWidth]);

  const cancelDrawing = () => {
    setIsDrawing(false);
    setCurrentPath([]);
    setCircleCenter(null);
    setCircleRadius(0);
    setRectangleStart(null);
    setDistancePoints([]);
    setMeasuredDistance(0);
  };

  const addMarker = useCallback((lat: number, lng: number) => {
    pushHistory();
    const newMarker: MapMarker = {
      id: `marker_${Date.now()}`,
      lat,
      lng,
      label: zoneName.trim() || `Marker ${markers.length + 1}`,
    };
    updateActiveLayer({ markers: [...markers, newMarker] });
    setZoneName('');
    setIsDrawing(false);
  }, [markers.length, zoneName]);

  const addDistancePoint = useCallback((lat: number, lng: number) => {
    setDistancePoints(prev => {
      const newPoints = [...prev, [lat, lng] as [number, number]];
      if (newPoints.length >= 2) {
        setMeasuredDistance(calculateTotalDistance(newPoints));
      }
      return newPoints;
    });
  }, []);

  const removeZone = (zoneId: string) => {
    pushHistory();
    updateActiveLayer({ zones: zones.filter((z) => z.id !== zoneId) });
    if (editingZoneId === zoneId) {
      setEditingZoneId(null);
      setShowZoneEditor(false);
      setSelectedPointIndex(null);
    }
  };

  const removeMarker = (markerId: string) => {
    pushHistory();
    updateActiveLayer({ markers: markers.filter((m) => m.id !== markerId) });
  };

  const removeLastPoint = () => {
    if (tool === 'polygon' || tool === 'line' || tool === 'distance') {
      setCurrentPath((prev) => {
        const newPath = prev.slice(0, -1);
        if (tool === 'distance' && newPath.length >= 2) {
          setMeasuredDistance(calculateTotalDistance(newPath));
        } else if (tool === 'distance') {
          setMeasuredDistance(0);
        }
        return newPath;
      });
    }
  };

  // Delete selected point from editing zone
  const deleteSelectedPoint = () => {
    if (editingZone && selectedPointIndex !== null && editingZone.paths.length > 3) {
      pushHistory();
      updateActiveLayer({
        zones: zones.map((z) =>
          z.id === editingZone.id
            ? { ...z, paths: z.paths.filter((_, i) => i !== selectedPointIndex) }
            : z
        )
      });
      setSelectedPointIndex(null);
    }
  };

  // Insert point after selected point
  const insertPointAfter = (lat: number, lng: number) => {
    if (editingZone && selectedPointIndex !== null) {
      pushHistory();
      const newPaths = [...editingZone.paths];
      newPaths.splice(selectedPointIndex + 1, 0, { lat, lng });
      updateActiveLayer({
        zones: zones.map((z) =>
          z.id === editingZone.id ? { ...z, paths: newPaths } : z
        )
      });
    }
  };

  const clearAll = () => {
    pushHistory();
    updateActiveLayer({ zones: [], markers: [] });
    setCurrentPath([]);
    setIsDrawing(false);
    setEditingZoneId(null);
    setShowZoneEditor(false);
    setDistancePoints([]);
    setMeasuredDistance(0);
    setSelectedPointIndex(null);
  };

  // Edit zone functions
  const startEditingZone = (zoneId: string) => {
    setEditingZoneId(zoneId);
    setShowZoneEditor(true);
    setIsDrawing(false);
    setCurrentPath([]);
    setSelectedPointIndex(null);
  };

  const updateZoneName = (zoneId: string, newName: string) => {
    pushHistory();
    updateActiveLayer({
      zones: zones.map((z) => (z.id === zoneId ? { ...z, name: newName } : z))
    });
  };

  const updateZoneColor = (zoneId: string, newColor: string) => {
    pushHistory();
    updateActiveLayer({
      zones: zones.map((z) => (z.id === zoneId ? { ...z, color: newColor } : z))
    });
  };

  const updateZoneOpacity = (zoneId: string, newOpacity: number) => {
    pushHistory();
    updateActiveLayer({
      zones: zones.map((z) => (z.id === zoneId ? { ...z, fillOpacity: newOpacity } : z))
    });
  };

  const updateZoneStrokeWidth = (zoneId: string, newWidth: number) => {
    pushHistory();
    updateActiveLayer({
      zones: zones.map((z) => (z.id === zoneId ? { ...z, strokeWidth: newWidth } : z))
    });
  };

  const movePoint = (zoneId: string, pointIndex: number, newLat: number, newLng: number) => {
    pushHistory();
    updateActiveLayer({
      zones: zones.map((z) =>
        z.id === zoneId
          ? {
              ...z,
              paths: z.paths.map((p, i) =>
                i === pointIndex ? { lat: newLat, lng: newLng } : p
              ),
            }
          : z
      )
    });
  };


  // Clone/Duplicate zone
  const cloneZone = (zoneId: string) => {
    pushHistory();
    const zone = zones.find(z => z.id === zoneId);
    if (!zone) return;
    const newZone: MapZone = {
      ...zone,
      id: `zone_${Date.now()}`,
      name: `${zone.name} (Copy)`,
      paths: zone.paths.map(p => ({ ...p, lat: p.lat + 0.01, lng: p.lng + 0.01 })), // Offset slightly
    };
    updateActiveLayer({ zones: [...zones, newZone] });
  };

  // Layer management
  const addLayer = () => {
    pushHistory();
    const newLayer: Layer = {
      id: `layer_${Date.now()}`,
      name: newLayerName.trim() || `Layer ${layers.length + 1}`,
      zones: [],
      markers: [],
      visible: true,
      locked: false,
      color: colors[layers.length % colors.length].color,
    };
    setLayers([...layers, newLayer]);
    setActiveLayerId(newLayer.id);
    setNewLayerName('');
  };

  const deleteLayer = (layerId: string) => {
    if (layers.length <= 1) return;
    pushHistory();
    const newLayers = layers.filter(l => l.id !== layerId);
    setLayers(newLayers);
    if (activeLayerId === layerId) {
      setActiveLayerId(newLayers[0].id);
    }
  };

  const toggleLayerVisibility = (layerId: string) => {
    setLayers(prev => prev.map(l => 
      l.id === layerId ? { ...l, visible: !l.visible } : l
    ));
  };

  const toggleLayerLock = (layerId: string) => {
    setLayers(prev => prev.map(l => 
      l.id === layerId ? { ...l, locked: !l.locked } : l
    ));
  };

  const duplicateLayer = (layerId: string) => {
    const layer = layers.find(l => l.id === layerId);
    if (!layer) return;
    pushHistory();
    const newLayer: Layer = {
      ...layer,
      id: `layer_${Date.now()}`,
      name: `${layer.name} (Copy)`,
      zones: layer.zones.map(z => ({ ...z, id: `zone_${Date.now()}_${Math.random()}` })),
      markers: layer.markers.map(m => ({ ...m, id: `marker_${Date.now()}_${Math.random()}` })),
    };
    setLayers([...layers, newLayer]);
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`
      );
      const data = await response.json();
      
      if (data && data.length > 0) {
        const { lat, lon } = data[0];
        setMapCenter([parseFloat(lat), parseFloat(lon)]);
        setMapZoom(12);
      }
    } catch (error) {
      console.error('Search failed:', error);
    }
  };

  const handleExport = () => {
    const allZones = layers.flatMap(l => l.zones);
    const allMarkers = layers.flatMap(l => l.markers);
    
    const data = {
      zones: allZones,
      markers: allMarkers,
      center: { lat: mapCenter[0], lng: mapCenter[1] },
      zoom: mapZoom,
      layers: layers.map(l => ({
        name: l.name,
        zoneCount: l.zones.length,
        markerCount: l.markers.length,
      })),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tsinephu-map-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    try {
      const data = JSON.parse(importData);
      pushHistory();
      if (data.zones) {
        updateActiveLayer({ zones: data.zones });
      }
      if (data.markers) {
        updateActiveLayer({ markers: data.markers });
      }
      if (data.center) {
        setMapCenter([data.center.lat, data.center.lng]);
      }
      if (data.zoom) {
        setMapZoom(data.zoom);
      }
      setShowImportDialog(false);
      setImportData('');
    } catch (error) {
      alert('Invalid JSON data');
    }
  };

  // GeoJSON import/export
  const handleExportGeoJSON = () => {
    const allZones = layers.flatMap(l => l.zones);
    
    const features = allZones.map(zone => {
      if (zone.type === 'circle' && zone.radius) {
        const points = 32;
        const coords = [];
        for (let i = 0; i < points; i++) {
          const angle = (i / points) * 2 * Math.PI;
          const lat = zone.paths[0].lat + (zone.radius / 111320) * Math.cos(angle);
          const lng = zone.paths[0].lng + (zone.radius / (111320 * Math.cos(zone.paths[0].lat * Math.PI / 180))) * Math.sin(angle);
          coords.push([lng, lat]);
        }
        coords.push(coords[0]);
        
        return {
          type: 'Feature',
          properties: { name: zone.name, color: zone.color, type: 'circle', fillOpacity: zone.fillOpacity, strokeWidth: zone.strokeWidth },
          geometry: { type: 'Polygon', coordinates: [coords] },
        };
      }
      
      return {
        type: 'Feature',
        properties: { name: zone.name, color: zone.color, type: zone.type || 'polygon', fillOpacity: zone.fillOpacity, strokeWidth: zone.strokeWidth },
        geometry: {
          type: 'Polygon',
          coordinates: [zone.paths.map(p => [p.lng, p.lat]).concat([[zone.paths[0].lng, zone.paths[0].lat]])],
        },
      };
    });

    const geoJSON = {
      type: 'FeatureCollection',
      features,
    };

    const blob = new Blob([JSON.stringify(geoJSON, null, 2)], { type: 'application/geo+json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tsinephu-map-${Date.now()}.geojson`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportGeoJSON = () => {
    try {
      const geoJSON = JSON.parse(geoJSONData);
      if (geoJSON.type === 'FeatureCollection' && geoJSON.features) {
        pushHistory();
        const importedZones: MapZone[] = geoJSON.features.map((f: any, index: number) => ({
          id: `zone_import_${Date.now()}_${index}`,
          name: f.properties?.name || `Imported ${index + 1}`,
          color: f.properties?.color || selectedColor,
          type: f.properties?.type || 'polygon',
          fillOpacity: f.properties?.fillOpacity || DEFAULT_FILL_OPACITY,
          strokeWidth: f.properties?.strokeWidth || DEFAULT_STROKE_WIDTH,
          paths: f.geometry?.coordinates?.[0]?.map((c: number[]) => ({ lat: c[1], lng: c[0] })) || [],
        }));
        
        updateActiveLayer({ zones: [...zones, ...importedZones] });
        setShowGeoJSONDialog(false);
        setGeoJSONData('');
      }
    } catch (error) {
      alert('Invalid GeoJSON data');
    }
  };

  const handleSave = () => {
    const allZones = layers.flatMap(l => l.visible ? l.zones : []);
    const allMarkers = layers.flatMap(l => l.visible ? l.markers : []);
    
    if (allZones.length === 0 && allMarkers.length === 0) return;
    
    const mapData: MapData = {
      center: { lat: mapCenter[0], lng: mapCenter[1] },
      zoom: mapZoom,
      zones: allZones,
      markers: allMarkers,
    };
    onSave(mapData);
  };

  const editingZone = editingZoneId ? zones.find((z) => z.id === editingZoneId) : null;

  // Calculate total area
  const totalArea = zones.reduce((sum, zone) => {
    if (zone.type === 'circle' && zone.radius) {
      return sum + (Math.PI * zone.radius * zone.radius) / 1000000;
    }
    return sum + calculatePolygonArea(zone.paths.map(p => [p.lat, p.lng]) as [number, number][]);
  }, 0);

  // Get all visible zones and markers from all layers
  const allVisibleZones = layers.flatMap(l => l.visible ? l.zones : []);
  const allVisibleMarkers = layers.flatMap(l => l.visible ? l.markers : []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+Z / Cmd+Z for undo
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
      }
      // Ctrl+Y / Cmd+Shift+Z for redo
      if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) {
        e.preventDefault();
        redo();
      }
      // Escape to cancel drawing
      if (e.key === 'Escape') {
        if (isDrawing) {
          cancelDrawing();
        } else if (editingZoneId) {
          setEditingZoneId(null);
          setShowZoneEditor(false);
          setSelectedPointIndex(null);
        }
      }
      // Delete key to remove selected point or zone
      if (e.key === 'Delete') {
        if (selectedPointIndex !== null && editingZone) {
          deleteSelectedPoint();
        } else if (editingZoneId && !isDrawing) {
          removeZone(editingZoneId);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [undo, redo, isDrawing, editingZoneId, selectedPointIndex, editingZone]);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="font-semibold flex items-center gap-2">
          <MapIcon className="h-5 w-5" />
          {initialData ? t('editMap') : t('createMap')}
          {(allVisibleZones.length > 0 || allVisibleMarkers.length > 0) && (
            <span className="text-sm font-normal text-muted-foreground">
              ({allVisibleZones.length} {t('zones')}, {allVisibleMarkers.length} {t('markers')})
            </span>
          )}
        </h3>
        <div className="flex gap-2">
          {/* Undo/Redo buttons */}
          <Button 
            variant="outline" 
            size="sm" 
            onClick={undo} 
            disabled={historyIndex <= 0}
            title="Undo (Ctrl+Z)"
          >
            <Undo className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={redo} 
            disabled={historyIndex >= history.length - 1}
            title="Redo (Ctrl+Y)"
          >
            <Redo className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={onCancel}>
            {t('cancel')}
          </Button>
          <Button
            size="sm"
            onClick={handleSave}
            disabled={allVisibleZones.length === 0 && allVisibleMarkers.length === 0}
            className="bg-[#DC143C] hover:bg-[#B01030]"
          >
            {initialData ? t('saveChanges') : t('addMap')}
          </Button>
        </div>
      </div>

      {/* Stats Bar */}
      {(allVisibleZones.length > 0 || allVisibleMarkers.length > 0) && (
        <div className="flex flex-wrap gap-4 p-3 bg-muted/50 rounded-lg text-sm">
          <span className="flex items-center gap-1">
            <MapIcon className="h-4 w-4 text-primary" />
            {t('zoneCount').replace('{count}', String(allVisibleZones.length))}
          </span>
          <span className="flex items-center gap-1">
            <Crosshair className="h-4 w-4 text-primary" />
            {t('markerCount').replace('{count}', String(allVisibleMarkers.length))}
          </span>
          {showMeasurements && totalArea > 0 && (
            <span className="flex items-center gap-1">
              <Ruler className="h-4 w-4 text-primary" />
              ~{totalArea.toFixed(2)} km²
            </span>
          )}
          {measuredDistance > 0 && tool === 'distance' && (
            <span className="flex items-center gap-1 text-blue-500">
              <Navigation className="h-4 w-4" />
              {measuredDistance.toFixed(2)} km
            </span>
          )}
        </div>
      )}

      {/* Layer Selector */}
      <div className="flex flex-wrap items-center gap-2 p-3 bg-muted/50 rounded-lg">
        <Layers className="h-4 w-4 text-muted-foreground" />
        <select
          value={activeLayerId}
          onChange={(e) => setActiveLayerId(e.target.value)}
          className="h-9 px-2 rounded-md border bg-background text-sm"
        >
          {layers.map(layer => (
            <option key={layer.id} value={layer.id}>
              {layer.name} ({t('zoneCount').replace('{count}', String(layer.zones.length))}, {t('markerCount').replace('{count}', String(layer.markers.length))})
            </option>
          ))}
        </select>
        <Button
          size="sm"
          variant="outline"
          onClick={() => setShowLayerDialog(true)}
        >
          <Edit2 className="h-3 w-3 mr-1" />
          {t('manageLayers')}
        </Button>
        <div className="flex-1" />
        <span className="text-xs text-muted-foreground">
          {layers.length === 1 ? t('layerCount').replace('{count}', String(layers.length)) : t('layerCountPlural').replace('{count}', String(layers.length))}
        </span>
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2 p-3 bg-muted/50 rounded-lg">
        {/* Drawing Tools */}
        <div className="flex gap-1 flex-wrap">
          <Button
            size="sm"
            variant={tool === 'polygon' && isDrawing ? 'default' : 'outline'}
            onClick={() => startDrawing('polygon')}
            className={tool === 'polygon' && isDrawing ? 'bg-[#DC143C]' : ''}
            title={t('drawPolygon')}
          >
            <Hexagon className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={tool === 'circle' && isDrawing ? 'default' : 'outline'}
            onClick={() => startDrawing('circle')}
            className={tool === 'circle' && isDrawing ? 'bg-[#DC143C]' : ''}
            title={t('drawCircle')}
          >
            <CircleIcon className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={tool === 'rectangle' && isDrawing ? 'default' : 'outline'}
            onClick={() => startDrawing('rectangle')}
            className={tool === 'rectangle' && isDrawing ? 'bg-[#DC143C]' : ''}
            title={t('drawRectangle')}
          >
            <Square className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={tool === 'line' && isDrawing ? 'default' : 'outline'}
            onClick={() => startDrawing('line')}
            className={tool === 'line' && isDrawing ? 'bg-[#DC143C]' : ''}
            title={t('drawLine')}
          >
            <Navigation className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={tool === 'distance' && isDrawing ? 'default' : 'outline'}
            onClick={() => startDrawing('distance')}
            className={tool === 'distance' && isDrawing ? 'bg-[#DC143C]' : ''}
            title={t('measureDistance')}
          >
            <Ruler className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={tool === 'marker' && isDrawing ? 'default' : 'outline'}
            onClick={() => startDrawing('marker')}
            className={tool === 'marker' && isDrawing ? 'bg-[#DC143C]' : ''}
            title={t('addMarker')}
          >
            <Crosshair className="h-4 w-4" />
          </Button>
        </div>

        <div className="w-px h-8 bg-border mx-2 hidden sm:block" />

        {/* Zone name input */}
        <Input
          placeholder={t('nameOptional')}
          value={zoneName}
          onChange={(e) => setZoneName(e.target.value)}
          className="w-32"
          disabled={isDrawing && tool !== 'polygon' && tool !== 'circle' && tool !== 'rectangle' && tool !== 'line'}
        />

        {/* Color picker */}
        <div className="flex gap-1 flex-wrap max-w-[200px]">
          {colors.map(({ color }) => (
            <button
              key={color}
              onClick={() => setSelectedColor(color)}
              disabled={isDrawing}
              className={`w-6 h-6 rounded-full border-2 transition-all ${
                selectedColor === color
                  ? 'border-black scale-110'
                  : 'border-transparent hover:scale-105'
              }`}
              style={{ backgroundColor: color }}
            />
          ))}
        </div>

        <div className="flex-1" />

        {/* Map Style */}
        <select
          value={mapStyle}
          onChange={(e) => setMapStyle(e.target.value as MapStyle)}
          className="h-9 px-2 rounded-md border bg-background text-sm"
        >
          {Object.entries(mapStyles).map(([key, { name }]) => (
            <option key={key} value={key}>{name}</option>
          ))}
        </select>

        {/* View Options */}
        <Button
          size="sm"
          variant={showLabels ? 'default' : 'outline'}
          onClick={() => setShowLabels(!showLabels)}
          title={t('toggleLabels')}
        >
          <Type className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          variant={showMeasurements ? 'default' : 'outline'}
          onClick={() => setShowMeasurements(!showMeasurements)}
          title={t('toggleMeasurements')}
        >
          <Ruler className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() => setIsFullscreen(!isFullscreen)}
          title={isFullscreen ? t('exitFullscreen') : t('fullscreen')}
        >
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </Button>
      </div>

      {/* Advanced Options Bar */}
      <div className="flex flex-wrap items-center gap-4 p-3 bg-muted/30 rounded-lg">
        {/* Fill Opacity */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">{t('fillOpacity') || 'Fill Opacity'}</span>
          <Slider
            value={[fillOpacity * 100]}
            onValueChange={([v]) => setFillOpacity(v / 100)}
            min={0}
            max={100}
            step={5}
            className="w-24"
          />
          <span className="text-xs w-8">{(fillOpacity * 100).toFixed(0)}%</span>
        </div>

        {/* Stroke Width */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">{t('strokeWidth') || 'Stroke'}</span>
          <Slider
            value={[strokeWidth]}
            onValueChange={([v]) => setStrokeWidth(v)}
            min={1}
            max={10}
            step={1}
            className="w-24"
          />
          <span className="text-xs w-4">{strokeWidth}px</span>
        </div>

        {/* Snap to Grid */}
        <div className="flex items-center gap-2">
          <Magnet className="h-4 w-4 text-muted-foreground" />
          <span className="text-xs text-muted-foreground">{t('snapToGrid') || 'Snap'}</span>
          <Switch
            checked={snapToGrid}
            onCheckedChange={setSnapToGrid}
          />
          {snapToGrid && (
            <select
              value={gridSize}
              onChange={(e) => setGridSize(parseFloat(e.target.value))}
              className="h-7 px-1 rounded border bg-background text-xs"
            >
              <option value={0.001}>0.001° (~100m)</option>
              <option value={0.01}>0.01° (~1km)</option>
              <option value={0.1}>0.1° (~10km)</option>
            </select>
          )}
        </div>
      </div>

      {/* Drawing Controls */}
      {isDrawing && (
        <div className="flex flex-wrap items-center gap-2 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg">
          <span className="text-sm font-medium flex items-center gap-2">
            <Edit2 className="h-4 w-4" />
            {tool === 'polygon' && t('clickToAddPoints')}
            {tool === 'line' && t('clickToAddPoints')}
            {tool === 'distance' && t('clickToMeasure').replace('{distance}', measuredDistance.toFixed(2))}
            {tool === 'circle' && (circleCenter ? t('clickToSetRadius') : t('clickToSetCenter'))}
            {tool === 'rectangle' && (rectangleStart ? t('clickToSetCorner') : t('clickToStartRectangle'))}
            {tool === 'marker' && t('clickToPlaceMarker')}
          </span>
          <div className="flex-1" />
          {(tool === 'polygon' || tool === 'line' || tool === 'distance') && (
            <Button
              size="sm"
              variant="outline"
              onClick={removeLastPoint}
              disabled={currentPath.length === 0}
            >
              <Undo className="h-4 w-4 mr-1" />
              {t('undo')}
            </Button>
          )}
          <Button
            size="sm"
            variant="outline"
            onClick={cancelDrawing}
          >
            <X className="h-4 w-4 mr-1" />
            {t('cancel')}
          </Button>
          {tool !== 'marker' && tool !== 'distance' && (
            <Button
              size="sm"
              onClick={finishDrawing}
              disabled={
                (tool === 'polygon' && currentPath.length < 3) ||
                (tool === 'line' && currentPath.length < 2) ||
                (tool === 'circle' && (!circleCenter || circleRadius === 0)) ||
                (tool === 'rectangle' && !rectangleStart)
              }
              className="bg-[#DC143C] hover:bg-[#B01030]"
            >
              <Check className="h-4 w-4 mr-1" />
              {t('finish')}
            </Button>
          )}
        </div>
      )}

      {/* Zone Editor Panel */}
      {showZoneEditor && editingZone && (
        <div className="p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-medium flex items-center gap-2">
              <Edit2 className="h-4 w-4" />
              {t('editingName').replace('{name}', editingZone.name)}
            </h4>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => cloneZone(editingZone.id)}
                title="Clone zone"
              >
                <Copy className="h-3 w-3 mr-1" />
                Clone
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setShowZoneEditor(false);
                  setEditingZoneId(null);
                  setSelectedPointIndex(null);
                }}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-3">
            <div className="flex items-center gap-2">
              <span className="text-sm">{t('nameLabel')}</span>
              <Input
                value={editingZone.name}
                onChange={(e) => updateZoneName(editingZone.id, e.target.value)}
                className="w-32 h-8"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Palette className="h-4 w-4" />
              <div className="flex gap-1">
                {colors.map(({ color }) => (
                  <button
                    key={color}
                    onClick={() => updateZoneColor(editingZone.id, color)}
                    className={`w-5 h-5 rounded-full border-2 transition-all ${
                      editingZone.color === color
                        ? 'border-black scale-110'
                        : 'border-transparent hover:scale-105'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            {/* Opacity control for editing zone */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Opacity</span>
              <Slider
                value={[((editingZone.fillOpacity || DEFAULT_FILL_OPACITY) * 100)]}
                onValueChange={([v]) => updateZoneOpacity(editingZone.id, v / 100)}
                min={0}
                max={100}
                step={5}
                className="w-20"
              />
            </div>

            {/* Stroke width for editing zone */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Stroke</span>
              <Slider
                value={[editingZone.strokeWidth || DEFAULT_STROKE_WIDTH]}
                onValueChange={([v]) => updateZoneStrokeWidth(editingZone.id, v)}
                min={1}
                max={10}
                step={1}
                className="w-20"
              />
            </div>
          </div>

          {/* Point editing info */}
          {editingZone.paths.length > 0 && (
            <div className="text-xs text-muted-foreground">
              {editingZone.paths.length} points — Click points to select, drag to move, Delete key to remove selected
            </div>
          )}
        </div>
      )}

      {/* Search Bar */}
      {showSearch && (
        <div className="flex gap-2">
          <Input
            placeholder={t('searchLocation')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          />
          <Button onClick={handleSearch}>
            <Search className="h-4 w-4" />
          </Button>
          <Button variant="outline" onClick={() => setShowSearch(false)}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Map */}
      <div className={`relative border rounded-xl overflow-hidden transition-all ${isFullscreen ? 'fixed inset-0 z-50 rounded-none' : ''}`} style={{ height: isFullscreen ? '100vh' : '500px' }}>
        <MapContainer
          center={mapCenter}
          zoom={mapZoom}
          style={{ height: '100%', width: '100%' }}
          scrollWheelZoom={true}
          doubleClickZoom={!isDrawing}
        >
          <MapController center={mapCenter} zoom={mapZoom} />
          
          <TileLayer
            attribution='&copy; OpenStreetMap contributors'
            url={mapStyles[mapStyle].url}
          />

          {/* Drawing handler */}
          <DrawingHandler
            tool={tool}
            isDrawing={isDrawing}
            currentPath={currentPath}
            setCurrentPath={setCurrentPath}
            onFinishDrawing={finishDrawing}
            onAddMarker={addMarker}
            circleCenter={circleCenter}
            setCircleCenter={setCircleCenter}
            setCircleRadius={setCircleRadius}
            rectangleStart={rectangleStart}
            setRectangleStart={setRectangleStart}
            onAddDistancePoint={addDistancePoint}
            snapToGrid={snapToGrid}
            gridSize={gridSize}
          />

          {/* Edit mode click handler for inserting points */}
          {editingZone && selectedPointIndex !== null && (
            <MapClickHandler
              onClick={(lat, lng) => insertPointAfter(lat, lng)}
            />
          )}

          {/* Render zones from all visible layers */}
          {layers.filter(l => l.visible).flatMap(l => l.zones).map((zone) => {
            const isEditing = editingZoneId === zone.id;
            const zFillOpacity = zone.fillOpacity ?? fillOpacity;
            const zStrokeWidth = zone.strokeWidth ?? strokeWidth;
            
            if (zone.type === 'circle' && zone.radius) {
              return (
                <Circle
                  key={zone.id}
                  center={[zone.paths[0].lat, zone.paths[0].lng]}
                  radius={zone.radius}
                  pathOptions={{
                    fillColor: zone.color,
                    fillOpacity: isEditing ? zFillOpacity + 0.2 : zFillOpacity,
                    color: zone.color,
                    weight: isEditing ? zStrokeWidth + 1 : zStrokeWidth,
                  }}
                  eventHandlers={{
                    click: () => !isDrawing && startEditingZone(zone.id),
                  }}
                />
              );
            }
            
            return (
              <Polygon
                key={zone.id}
                positions={zone.paths.map((p) => [p.lat, p.lng])}
                pathOptions={{
                  fillColor: zone.color,
                  fillOpacity: isEditing ? zFillOpacity + 0.2 : zFillOpacity,
                  color: zone.color,
                  weight: isEditing ? zStrokeWidth + 1 : zStrokeWidth,
                }}
                eventHandlers={{
                  click: () => !isDrawing && startEditingZone(zone.id),
                }}
              />
            );
          })}

          {/* Zone labels */}
          {showLabels && layers.filter(l => l.visible).flatMap(l => l.zones).map((zone) => (
            <Marker
              key={`label-${zone.id}`}
              position={[
                zone.paths.reduce((sum, p) => sum + p.lat, 0) / zone.paths.length,
                zone.paths.reduce((sum, p) => sum + p.lng, 0) / zone.paths.length,
              ]}
              icon={new Icon({
                iconUrl: 'data:image/svg+xml;base64,' + btoa(`
                  <svg xmlns="http://www.w3.org/2000/svg" width="${zone.name.length * 8 + 16}" height="24">
                    <rect x="0" y="0" width="${zone.name.length * 8 + 16}" height="24" rx="4" fill="${zone.color}" opacity="0.9"/>
                    <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="white" font-size="12" font-weight="bold">${zone.name}</text>
                  </svg>
                `),
                iconSize: [zone.name.length * 8 + 16, 24],
                iconAnchor: [(zone.name.length * 8 + 16) / 2, 12],
              })}
              interactive={false}
            />
          ))}

          {/* Markers from all visible layers */}
          {layers.filter(l => l.visible).flatMap(l => l.markers).map((marker) => (
            <Marker
              key={marker.id}
              position={[marker.lat, marker.lng]}
              icon={markerIcon}
            >
              <Popup>
                <div className="text-sm font-medium">{marker.label}</div>
                <Button
                  size="sm"
                  variant="destructive"
                  className="mt-2"
                  onClick={() => removeMarker(marker.id)}
                >
                  <Trash2 className="h-3 w-3 mr-1" />
                  {t('remove')}
                </Button>
              </Popup>
            </Marker>
          ))}

          {/* Zone point markers for editing - with selection highlight */}
          {editingZone &&
            editingZone.paths.map((point, index) => (
              <Marker
                key={`${editingZone.id}-point-${index}`}
                position={[point.lat, point.lng]}
                icon={selectedPointIndex === index ? 
                  new Icon({
                    iconUrl: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDA3YmZmIiBzdHJva2Utd2lkdGg9IjQiPjxjaXJjbGUgY3g9IjEyIiBjeT0iMTIiIHI9IjgiLz48L3N2Zz4=',
                    iconSize: [20, 20],
                    iconAnchor: [10, 10],
                  }) : editIcon
                }
                draggable={true}
                eventHandlers={{
                  click: () => setSelectedPointIndex(index),
                  dragend: (e) => {
                    const { lat, lng } = e.target.getLatLng();
                    movePoint(editingZone.id, index, lat, lng);
                  },
                }}
              />
            ))}

          {/* Current drawing path */}
          {currentPath.length > 0 && (tool === 'polygon' || tool === 'line' || tool === 'distance') && (
            <Polyline
              positions={currentPath}
              pathOptions={{
                color: selectedColor,
                weight: strokeWidth,
                dashArray: '5, 10',
              }}
            />
          )}

          {/* Distance measurement points */}
          {tool === 'distance' && distancePoints.map((point, index) => (
            <Marker
              key={`dist-point-${index}`}
              position={point}
              icon={distanceIcon}
            />
          ))}

          {/* Circle preview */}
          {tool === 'circle' && circleCenter && (
            <Circle
              center={circleCenter}
              radius={circleRadius}
              pathOptions={{
                fillColor: selectedColor,
                fillOpacity: fillOpacity * 0.5,
                color: selectedColor,
                weight: strokeWidth,
                dashArray: '5, 10',
              }}
            />
          )}

          {/* Rectangle preview */}
          {tool === 'rectangle' && rectangleStart && currentPath.length > 0 && (
            <Rectangle
              bounds={[
                rectangleStart,
                currentPath[currentPath.length - 1],
              ]}
              pathOptions={{
                fillColor: selectedColor,
                fillOpacity: fillOpacity * 0.5,
                color: selectedColor,
                weight: strokeWidth,
                dashArray: '5, 10',
              }}
            />
          )}

          {/* Drawing path markers */}
          {isDrawing && (tool === 'polygon' || tool === 'line' || tool === 'distance') &&
            currentPath.map((point, index) => (
              <Marker
                key={`draw-point-${index}`}
                position={point}
                icon={editIcon}
              />
            ))}
        </MapContainer>

        {/* Map Controls Overlay */}
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          <Button
            size="sm"
            variant="secondary"
            onClick={() => setMapZoom(z => z + 1)}
          >
            <Plus className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={() => setMapZoom(z => z - 1)}
          >
            <Minus className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={() => setShowSearch(!showSearch)}
          >
            <Search className="h-4 w-4" />
          </Button>
          {isFullscreen && (
            <Button
              size="sm"
              variant="secondary"
              onClick={() => setIsFullscreen(false)}
            >
              <Minimize2 className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Drawing indicator */}
        {isDrawing && (
          <div className="absolute top-4 left-4 bg-[#DC143C] text-white px-3 py-1.5 rounded-full text-sm font-medium shadow-lg">
            <Edit2 className="h-4 w-4 inline mr-1" />
            {tool === 'polygon' && `${t('drawingPolygon')} - ${currentPath.length} ${t('points') || 'points'}`}
            {tool === 'line' && `${t('drawingLine')} - ${currentPath.length} ${t('points') || 'points'}`}
            {tool === 'distance' && `${t('measuring')} - ${measuredDistance.toFixed(2)} ${t('km')}`}
            {tool === 'circle' && (circleCenter ? t('setRadius') : t('setCenter'))}
            {tool === 'rectangle' && (rectangleStart ? t('setCorner') : t('startRectangle'))}
            {tool === 'marker' && t('placeMarker')}
          </div>
        )}

        {/* Edit mode indicator */}
        {editingZone && (
          <div className="absolute top-4 left-4 bg-blue-500 text-white px-3 py-1.5 rounded-full text-sm font-medium shadow-lg">
            <Edit2 className="h-4 w-4 inline mr-1" />
            {t('editingName').replace('{name}', editingZone.name)}
            {selectedPointIndex !== null && (
              <span className="ml-2 text-xs opacity-80">(Point {selectedPointIndex + 1} selected)</span>
            )}
          </div>
        )}

        {/* Import/Export buttons */}
        <div className="absolute bottom-4 right-4 flex gap-2 flex-wrap">
          <Button
            size="sm"
            variant="secondary"
            onClick={() => setShowImportDialog(true)}
          >
            <Upload className="h-4 w-4 mr-1" />
            {t('import')}
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={() => setShowGeoJSONDialog(true)}
          >
            <FileJson className="h-4 w-4 mr-1" />
            GeoJSON
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={handleExport}
            disabled={allVisibleZones.length === 0 && allVisibleMarkers.length === 0}
          >
            <Download className="h-4 w-4 mr-1" />
            {t('export')}
          </Button>
        </div>
      </div>

      {/* Zone and Marker List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Zones */}
        {zones.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm font-medium flex items-center gap-2">
              <MapIcon className="h-4 w-4" />
              {t('zones')} ({zones.length})
            </p>
            <div className="flex flex-wrap gap-2">
              {zones.map((zone) => (
                <div
                  key={zone.id}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm border transition-all ${
                    editingZoneId === zone.id
                      ? 'ring-2 ring-blue-500 ring-offset-2'
                      : ''
                  }`}
                  style={{
                    backgroundColor: `${zone.color}20`,
                    borderColor: zone.color,
                  }}
                >
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: zone.color }}
                  />
                  <span className="font-medium">{zone.name}</span>
                  {showMeasurements && zone.type === 'circle' && zone.radius && (
                    <span className="text-xs text-muted-foreground">
                      (~{((Math.PI * zone.radius * zone.radius) / 1000000).toFixed(1)} km²)
                    </span>
                  )}
                  <button
                    onClick={() => startEditingZone(zone.id)}
                    className={`ml-1 hover:text-blue-500 transition-colors ${
                      editingZoneId === zone.id ? 'text-blue-500' : ''
                    }`}
                    title={t('editZone')}
                  >
                    <Edit2 className="h-3 w-3" />
                  </button>
                  <button
                    onClick={() => cloneZone(zone.id)}
                    className="ml-1 hover:text-green-500 transition-colors"
                    title="Clone zone"
                  >
                    <Copy className="h-3 w-3" />
                  </button>
                  <button
                    onClick={() => removeZone(zone.id)}
                    className="ml-1 hover:text-destructive transition-colors"
                    title={t('deleteZone')}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Markers */}
        {markers.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm font-medium flex items-center gap-2">
              <Crosshair className="h-4 w-4" />
              {t('markers')} ({markers.length})
            </p>
            <div className="flex flex-wrap gap-2">
              {markers.map((marker) => (
                <div
                  key={marker.id}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full text-sm border bg-muted/50"
                >
                  <Crosshair className="h-3 w-3 text-primary" />
                  <span className="font-medium">{marker.label}</span>
                  <button
                    onClick={() => removeMarker(marker.id)}
                    className="ml-1 hover:text-destructive transition-colors"
                    title={t('deleteMarker')}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Clear All */}
      {(zones.length > 0 || markers.length > 0) && (
        <div className="flex justify-end">
          <Button
            size="sm"
            variant="destructive"
            onClick={clearAll}
          >
            <Trash2 className="h-4 w-4 mr-1" />
            {t('clearAll')}
          </Button>
        </div>
      )}

      {/* Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('importMapData')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <textarea
              value={importData}
              onChange={(e) => setImportData(e.target.value)}
              placeholder={t('pasteJSONMapData')}
              className="w-full h-40 p-3 rounded-md border bg-background font-mono text-sm"
            />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowImportDialog(false)}>
                {t('cancel')}
              </Button>
              <Button onClick={handleImport} disabled={!importData.trim()}>
                {t('import')}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* GeoJSON Dialog */}
      <Dialog open={showGeoJSONDialog} onOpenChange={setShowGeoJSONDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileJson className="h-5 w-5" />
              GeoJSON
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex gap-2">
              <Button onClick={handleExportGeoJSON} disabled={allVisibleZones.length === 0}>
                <Download className="h-4 w-4 mr-2" />
                {t('exportGeoJSON')}
              </Button>
            </div>
            <div className="border-t pt-4">
              <p className="text-sm text-muted-foreground mb-2">{t('importGeoJSONTitle')}</p>
              <textarea
                value={geoJSONData}
                onChange={(e) => setGeoJSONData(e.target.value)}
                placeholder={t('pasteGeoJSONData')}
                className="w-full h-40 p-3 rounded-md border bg-background font-mono text-sm"
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowGeoJSONDialog(false)}>
                {t('cancel')}
              </Button>
              <Button onClick={handleImportGeoJSON} disabled={!geoJSONData.trim()}>
                <Upload className="h-4 w-4 mr-2" />
                {t('importGeoJSON')}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Layer Management Dialog */}
      <Dialog open={showLayerDialog} onOpenChange={setShowLayerDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Layers className="h-5 w-5" />
              {t('manageLayers')}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Layer List */}
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {layers.map((layer) => (
                <div
                  key={layer.id}
                  className={`flex items-center gap-2 p-3 rounded-lg border ${
                    layer.id === activeLayerId ? 'border-primary bg-primary/5' : 'border-border'
                  }`}
                >
                  <button
                    onClick={() => toggleLayerVisibility(layer.id)}
                    className="p-1 hover:bg-muted rounded"
                  >
                    {layer.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                  </button>
                  <button
                    onClick={() => toggleLayerLock(layer.id)}
                    className="p-1 hover:bg-muted rounded"
                  >
                    {layer.locked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
                  </button>
                  <span 
                    className="flex-1 cursor-pointer"
                    onClick={() => {
                      setActiveLayerId(layer.id);
                      setShowLayerDialog(false);
                    }}
                  >
                    {layer.name}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {t('zoneCount').replace('{count}', String(layer.zones.length))}, {t('markerCount').replace('{count}', String(layer.markers.length))}
                  </span>
                  <button
                    onClick={() => duplicateLayer(layer.id)}
                    className="p-1 hover:bg-muted rounded"
                    title={t('duplicateLayer')}
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                  {layers.length > 1 && (
                    <button
                      onClick={() => deleteLayer(layer.id)}
                      className="p-1 hover:bg-destructive/10 hover:text-destructive rounded"
                      title={t('deleteLayer')}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>

            {/* Add New Layer */}
            <div className="border-t pt-4">
              <p className="text-sm font-medium mb-2">{t('addNewLayer')}</p>
              <div className="flex gap-2">
                <Input
                  placeholder={t('layerName')}
                  value={newLayerName}
                  onChange={(e) => setNewLayerName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addLayer()}
                />
                <Button onClick={addLayer} disabled={!newLayerName.trim()}>
                  <Plus className="h-4 w-4 mr-1" />
                  {t('add')}
                </Button>
              </div>
            </div>

            <div className="flex justify-end">
              <Button variant="outline" onClick={() => setShowLayerDialog(false)}>
                {t('close')}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
