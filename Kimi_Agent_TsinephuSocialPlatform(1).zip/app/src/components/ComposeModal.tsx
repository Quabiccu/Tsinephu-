import { useState, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useParniks } from '@/context/ParnikContext';
import { useLanguage } from '@/context/LanguageContext';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { X, BarChart3, Plus, Minus, Map as MapIcon, Upload, MapPin } from 'lucide-react';
import { MapParnikDrawer } from './MapParnikDrawer';
import type { Poll, MapData } from '@/types';

interface ComposeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const MAX_CHARS = 500;
const MAX_POLL_OPTIONS = 4;
const MIN_POLL_OPTIONS = 2;
const MAX_IMAGES = 4;

export function ComposeModal({ isOpen, onClose }: ComposeModalProps) {
  const { user } = useAuth();
  const { createParnik } = useParniks();
  const { t } = useLanguage();
  const [content, setContent] = useState('');
  const [media, setMedia] = useState<string[]>([]);
  const [showPoll, setShowPoll] = useState(false);
  const [pollOptions, setPollOptions] = useState(['', '']);
  const [pollDuration, setPollDuration] = useState(1);
  const [showMap, setShowMap] = useState(false);
  const [mapData, setMapData] = useState<MapData | undefined>();
  const [isUploading, setIsUploading] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const charCount = content.length;
  const isOverLimit = charCount > MAX_CHARS;
  const canSubmit =
    (content.trim().length > 0 || showPoll || mapData || media.length > 0) &&
    !isOverLimit &&
    (!showPoll || pollOptions.every((opt) => opt.trim().length > 0));

  const handleSubmit = () => {
    if (!canSubmit) return;

    let poll: Poll | undefined;
    if (showPoll && pollOptions.every((opt) => opt.trim())) {
      poll = {
        id: `poll_${Date.now()}`,
        options: pollOptions.map((text, i) => ({
          id: `option_${i}`,
          text: text.trim(),
          votes: [],
        })),
        expiresAt: new Date(Date.now() + pollDuration * 24 * 60 * 60 * 1000),
        totalVotes: 0,
      };
    }

    createParnik(content, media.length > 0 ? media : undefined, poll, mapData);
    resetForm();
    onClose();
  };

  const resetForm = () => {
    setContent('');
    setMedia([]);
    setShowPoll(false);
    setShowMap(false);
    setMapData(undefined);
    setPollOptions(['', '']);
    setPollDuration(1);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    setIsUploading(true);
    const newImages: string[] = [];
    let processed = 0;

    Array.from(files).forEach((file) => {
      if (!file.type.startsWith('image/')) {
        processed++;
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          newImages.push(event.target.result as string);
        }
        processed++;
        if (processed === files.length) {
          setMedia((prev) => [...prev, ...newImages].slice(0, MAX_IMAGES));
          setIsUploading(false);
        }
      };
      reader.readAsDataURL(file);
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleImageUploadClick = () => {
    if (media.length >= MAX_IMAGES) return;
    fileInputRef.current?.click();
  };

  const removeImage = (index: number) => {
    setMedia((prev) => prev.filter((_, i) => i !== index));
  };

  const addPollOption = () => {
    if (pollOptions.length < MAX_POLL_OPTIONS) {
      setPollOptions((prev) => [...prev, '']);
    }
  };

  const removePollOption = (index: number) => {
    if (pollOptions.length > MIN_POLL_OPTIONS) {
      setPollOptions((prev) => prev.filter((_, i) => i !== index));
    }
  };

  const updatePollOption = (index: number, value: string) => {
    setPollOptions((prev) => prev.map((opt, i) => (i === index ? value : opt)));
  };

  const handleMapSave = (data: MapData) => {
    setMapData(data);
    setShowMap(false);
  };

  const removeMap = () => {
    setMapData(undefined);
  };

  if (!user) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-xl p-0 gap-0 max-h-[90vh] overflow-y-auto">
        <DialogHeader className="p-4 border-b border-border">
          <DialogTitle className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#DC143C] flex items-center justify-center">
              <span className="text-yellow-400 text-lg">⚡</span>
            </div>
            {t('newParnik')}
          </DialogTitle>
        </DialogHeader>

        <div className="p-4">
          <div className="flex gap-3">
            <img
              src={user.avatar}
              alt={user.displayName}
              className="h-10 w-10 rounded-full bg-muted flex-shrink-0 object-cover"
            />
            <div className="flex-1">
              <Textarea
                ref={textareaRef}
                placeholder={t('whatsOnMind')}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="min-h-[100px] resize-none border-0 focus-visible:ring-0 text-lg p-0"
              />

              {/* Media Preview */}
              {media.length > 0 && (
                <div
                  className={`grid gap-2 mt-3 ${
                    media.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
                  }`}
                >
                  {media.map((img, index) => (
                    <div key={index} className="relative rounded-xl overflow-hidden">
                      <img
                        src={img}
                        alt={`Upload ${index + 1}`}
                        className={`w-full object-cover ${
                          media.length === 1 ? 'h-48' : 'h-32'
                        }`}
                      />
                      <button
                        onClick={() => removeImage(index)}
                        className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-black/80 rounded-full text-white transition-colors"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Map Preview */}
              {mapData && !showMap && (
                <div className="mt-4 p-4 bg-muted/50 rounded-xl">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <MapIcon className="h-5 w-5 text-primary" />
                      <span className="font-medium">{t('mapParnik')}</span>
                      <span className="text-sm text-muted-foreground">
                        ({mapData.zones.length} {t('zones')})
                      </span>
                    </div>
                    <button
                      onClick={removeMap}
                      className="p-1.5 hover:bg-destructive/10 text-destructive rounded-full transition-colors"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                  {/* Mini map preview */}
                  <div
                    className="relative h-32 bg-[#e8f4f8] rounded-lg overflow-hidden"
                    style={{ height: '150px' }}
                  >
                    <iframe
                      src={`https://www.openstreetmap.org/export/embed.html?bbox=-180%2C-60%2C180%2C75&layer=mapnik`}
                      width="100%"
                      height="100%"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      title="Map Preview"
                    />
                    <div className="absolute bottom-2 right-2 flex gap-1">
                      {mapData.zones.slice(0, 5).map((zone) => (
                        <span
                          key={zone.id}
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: zone.color }}
                        />
                      ))}
                      {mapData.zones.length > 5 && (
                        <span className="text-xs text-muted-foreground">
                          +{mapData.zones.length - 5}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Poll */}
              {showPoll && (
                <div className="mt-4 p-4 bg-muted/50 rounded-xl space-y-3">
                  {pollOptions.map((option, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        placeholder={`${t('pollOption')} ${index + 1}`}
                        value={option}
                        onChange={(e) => updatePollOption(index, e.target.value)}
                        className="flex-1"
                      />
                      {pollOptions.length > MIN_POLL_OPTIONS && (
                        <button
                          onClick={() => removePollOption(index)}
                          className="p-2 text-muted-foreground hover:text-destructive transition-colors"
                        >
                          <Minus className="h-5 w-5" />
                        </button>
                      )}
                    </div>
                  ))}

                  {pollOptions.length < MAX_POLL_OPTIONS && (
                    <button
                      onClick={addPollOption}
                      className="flex items-center gap-2 text-primary hover:underline text-sm"
                    >
                      <Plus className="h-4 w-4" />
                      {t('addPoll')}
                    </button>
                  )}

                  <div className="flex items-center gap-2 pt-2 border-t border-border">
                    <span className="text-sm text-muted-foreground">
                      {t('pollDays')}:
                    </span>
                    <div className="flex gap-1">
                      {[1, 3, 7].map((days) => (
                        <button
                          key={days}
                          onClick={() => setPollDuration(days)}
                          className={`px-3 py-1 rounded-full text-sm transition-colors ${
                            pollDuration === days
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted hover:bg-muted/80'
                          }`}
                        >
                          {days}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Map Drawer */}
              {showMap && (
                <div className="mt-4">
                  <MapParnikDrawer onSave={handleMapSave} onCancel={() => setShowMap(false)} />
                </div>
              )}
            </div>
          </div>

          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileSelect}
            className="hidden"
          />

          {/* Divider */}
          <div className="border-t border-border my-4" />

          {/* Actions */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <button
                onClick={handleImageUploadClick}
                disabled={media.length >= MAX_IMAGES || isUploading}
                className="p-2 text-primary hover:bg-primary/10 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                title={`${t('addImageTitle')} (${media.length}/${MAX_IMAGES})`}
              >
                {isUploading ? (
                  <div className="h-5 w-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Upload className="h-5 w-5" />
                )}
              </button>
              <button
                onClick={() => setShowPoll(!showPoll)}
                className={`p-2 rounded-full transition-colors ${
                  showPoll
                    ? 'text-primary bg-primary/10'
                    : 'text-primary hover:bg-primary/10'
                }`}
                title={t('addPollTitle')}
              >
                <BarChart3 className="h-5 w-5" />
              </button>
              <button
                onClick={() => setShowMap(!showMap)}
                disabled={!!mapData}
                className={`p-2 rounded-full transition-colors ${
                  showMap || mapData
                    ? 'text-primary bg-primary/10'
                    : 'text-primary hover:bg-primary/10'
                } ${mapData ? 'opacity-50 cursor-not-allowed' : ''}`}
                title={t('addMapTitle')}
              >
                <MapPin className="h-5 w-5" />
              </button>
            </div>

            <div className="flex items-center gap-4">
              <span
                className={`text-sm ${
                  isOverLimit ? 'text-destructive' : 'text-muted-foreground'
                }`}
              >
                {charCount}/{MAX_CHARS} {t('characters')}
              </span>

              <Button
                onClick={handleSubmit}
                disabled={!canSubmit}
                className="rounded-full px-6 bg-[#DC143C] hover:bg-[#B01030]"
              >
                {t('post')}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
