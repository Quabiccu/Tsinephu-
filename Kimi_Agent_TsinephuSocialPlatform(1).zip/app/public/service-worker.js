/**
 * Tsinephu Service Worker
 * Provides: Offline support, Push notifications, Background sync, Cache management
 */

const CACHE_NAME = 'tsinephu-cache-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon-72x72.png',
  '/icon-96x96.png',
  '/icon-128x128.png',
  '/icon-144x144.png',
  '/icon-192x192.png',
  '/icon-512x512.png',
];

const NOTIFICATION_ICON = '/icon-192x192.png';
const NOTIFICATION_BADGE = '/icon-72x72.png';

// Install - cache static assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    }).then(() => {
      self.skipWaiting();
    })
  );
});

// Activate - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    }).then(() => {
      self.clients.claim();
    })
  );
});

// Fetch - serve from cache or network
self.addEventListener('fetch', (event) => {
  // Skip non-GET requests
  if (event.request.method !== 'GET') return;
  
  // Skip API requests (let them go to network)
  if (event.request.url.includes('/api/')) return;
  
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      // Return cached response if found
      if (cachedResponse) {
        // Revalidate in background
        fetch(event.request).then((networkResponse) => {
          if (networkResponse.ok) {
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, networkResponse);
            });
          }
        }).catch(() => {});
        return cachedResponse;
      }
      
      // Otherwise fetch from network
      return fetch(event.request).then((networkResponse) => {
        if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
          return networkResponse;
        }
        
        const responseToCache = networkResponse.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseToCache);
        });
        
        return networkResponse;
      }).catch(() => {
        // Return offline fallback if available
        if (event.request.mode === 'navigate') {
          return caches.match('/index.html');
        }
      });
    })
  );
});

// Push Notifications - handle incoming push messages
self.addEventListener('push', (event) => {
  if (!event.data) return;
  
  try {
    const data = event.data.json();
    const title = data.title || 'Tsinephu';
    const options = {
      body: data.body || 'New notification',
      icon: data.icon || NOTIFICATION_ICON,
      badge: data.badge || NOTIFICATION_BADGE,
      tag: data.tag || `tsinephu-${Date.now()}`,
      requireInteraction: data.requireInteraction || false,
      renotify: data.renotify || false,
      silent: data.silent || false,
      data: data.data || {},
      actions: data.actions || [
        {
          action: 'open',
          title: 'Open',
          icon: '/icon-72x72.png'
        },
        {
          action: 'dismiss',
          title: 'Dismiss',
          icon: '/icon-72x72.png'
        }
      ],
      // Android-specific vibrate pattern
      vibrate: data.vibrate || [200, 100, 200],
      // iOS-specific
      sound: '/notification-sound.mp3',
    };
    
    event.waitUntil(
      self.registration.showNotification(title, options)
    );
  } catch (error) {
    // Fallback for non-JSON push data
    const title = 'Tsinephu';
    const options = {
      body: event.data.text() || 'New notification',
      icon: NOTIFICATION_ICON,
      badge: NOTIFICATION_BADGE,
      vibrate: [200, 100, 200],
    };
    
    event.waitUntil(
      self.registration.showNotification(title, options)
    );
  }
});

// Notification click handling
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  const action = event.action;
  const data = event.notification.data || {};
  
  if (action === 'dismiss') {
    return;
  }
  
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // If app is already open, focus it
      for (const client of clientList) {
        if (client.url.includes(self.registration.scope) && 'focus' in client) {
          client.focus();
          // Post message to client with notification data
          client.postMessage({
            type: 'NOTIFICATION_CLICK',
            data: data,
            action: action,
          });
          return;
        }
      }
      
      // Otherwise open the app
      const url = data.url || '/';
      if (self.clients.openWindow) {
        self.clients.openWindow(url);
      }
    })
  );
});

// Background sync for offline queue
self.addEventListener('sync', (event) => {
  if (event.tag === 'tsinephu-post-sync') {
    event.waitUntil(syncPendingPosts());
  } else if (event.tag === 'tsinephu-notification-sync') {
    event.waitUntil(syncNotifications());
  }
});

// Periodic background sync for notifications
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'tsinephu-periodic-sync') {
    event.waitUntil(checkForNewNotifications());
  }
});

// Message handling from main thread
self.addEventListener('message', (event) => {
  const { type, payload } = event.data;
  
  switch (type) {
    case 'GET_NOTIFICATIONS_PERMISSION':
      // Return current permission status to client
      self.registration.pushManager.getSubscription().then((subscription) => {
        event.source.postMessage({
          type: 'NOTIFICATIONS_PERMISSION_RESULT',
          payload: {
            hasSubscription: !!subscription,
            subscription: subscription,
          },
        });
      });
      break;
      
    case 'SCHEDULE_NOTIFICATION':
      // Schedule a local notification
      scheduleLocalNotification(payload);
      break;
      
    case 'CANCEL_NOTIFICATION':
      // Cancel a scheduled notification
      cancelLocalNotification(payload.tag);
      break;
      
    case 'UPDATE_BADGE':
      // Update app badge count
      if ('setAppBadge' in navigator) {
        navigator.setAppBadge(payload.count).catch(() => {});
      }
      break;
      
    case 'CLEAR_BADGE':
      if ('clearAppBadge' in navigator) {
        navigator.clearAppBadge().catch(() => {});
      }
      break;
  }
});

// Helper functions
async function syncPendingPosts() {
  // Implementation would check IndexedDB for pending posts and sync them
  const clients = await self.clients.matchAll({ type: 'window' });
  clients.forEach(client => {
    client.postMessage({ type: 'SYNC_PENDING_POSTS' });
  });
}

async function syncNotifications() {
  // Sync notification status with server
  const clients = await self.clients.matchAll({ type: 'window' });
  clients.forEach(client => {
    client.postMessage({ type: 'SYNC_NOTIFICATIONS' });
  });
}

async function checkForNewNotifications() {
  // Check for new notifications from server
  // This is called periodically when the app is installed
  const clients = await self.clients.matchAll({ type: 'window' });
  clients.forEach(client => {
    client.postMessage({ type: 'CHECK_NEW_NOTIFICATIONS' });
  });
}

function scheduleLocalNotification(payload) {
  const { title, body, tag, delay, data } = payload;
  const timestamp = Date.now() + (delay || 0);
  
  // Store scheduled notification in IndexedDB
  // For simplicity, using a timeout here (real implementation would use alarms API)
  setTimeout(() => {
    self.registration.showNotification(title, {
      body,
      tag,
      icon: NOTIFICATION_ICON,
      badge: NOTIFICATION_BADGE,
      data,
      requireInteraction: true,
    });
  }, delay || 0);
}

function cancelLocalNotification(tag) {
  self.registration.getNotifications({ tag }).then((notifications) => {
    notifications.forEach((notification) => notification.close());
  });
}
